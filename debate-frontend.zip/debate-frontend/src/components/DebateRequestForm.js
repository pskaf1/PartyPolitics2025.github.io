import React, { useState } from 'react';

const DebateRequestForm = ({ topic, userId }) => {
  const [side, setSide] = useState(''); // Track the user's selected side
  const [consent, setConsent] = useState(false); // Track if the user consents to YouTube
  const [error, setError] = useState(null); // Track form errors
  const [success, setSuccess] = useState(null); // Track success message
  const [loading, setLoading] = useState(false); // Track loading state

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null); // Clear previous errors
    setSuccess(null); // Clear previous success messages

    if (!side) {
      setError('Please select a side for the debate.');
      return;
    }
    if (!consent) {
      setError('You must consent to the debate being posted on YouTube.');
      return;
    }

    setLoading(true); // Indicate the request is in progress

    try {
      const response = await fetch('http://localhost:3001/api/debate-request/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId, // User ID from props
          topicId: topic.id, // Debate topic ID from props
          side, // User's selected side
          consentForRecording: consent, // User's consent for recording
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess(data.message || 'Request submitted successfully!');
        setSide(''); // Reset form state
        setConsent(false);
        setError(null);
      } else {
        setError(data.message || 'Failed to submit request. Please try again.');
      }
    } catch (err) {
      setError('Error submitting request. Please check your connection and try again.');
    } finally {
      setLoading(false); // Stop loading indicator
    }
  };

  return (
    <div className="debate-request-form">
      <h2>Request to Debate: {topic.title}</h2>
      {error && <p className="error">{error}</p>}
      {success && <p className="success">{success}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Select your side:</label>
          <select value={side} onChange={(e) => setSide(e.target.value)}>
            <option value="">Select Side</option>
            <option value="for">For</option>
            <option value="against">Against</option>
          </select>
        </div>
        <div>
          <label>
            <input
              type="checkbox"
              checked={consent}
              onChange={() => setConsent(!consent)}
            />
            I consent to having this debate posted on YouTube
          </label>
        </div>
        <button type="submit" disabled={loading}>
          {loading ? 'Submitting...' : 'Submit Request'}
        </button>
      </form>
    </div>
  );
};

export default DebateRequestForm;
